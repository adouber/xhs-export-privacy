# 小红书笔记导出扩展 · M1

浏览器扩展（MV3，Edge / Chrome）：在小红书网页版把当前图文笔记一键转成「阅读版 HTML → PDF（打印流）」。

## 安装（开发者模式加载）

1. 打开 Edge，地址栏输入 `edge://extensions`（Chrome 为 `chrome://extensions`）
2. 打开右上角/左下角 **「开发人员模式 / 开发者模式」** 开关
3. 点击 **「加载解压缩的扩展」**，选择本目录 `xhs-export-extension/`
4. 打开任意一篇小红书图文笔记页（`xiaohongshu.com/explore/…`），工具栏出现红色扩展图标

## M1 使用流程

1. 在笔记页**滚动加载出评论区**（如需收录评论；评论接口是滚动时才请求的）
2. 点击扩展图标 → 弹窗显示解析摘要（标题/作者/字数/配图数/话题数/评论数）
3. 勾选「收录评论」（默认关）→ 点 **「生成阅读版预览」**
4. 新标签页打开阅读版预览：可切字号（A−/A+）、主题（纸张/浅色/深色）
5. 点 **「按页预览 / 打印 (Cmd+P)」** → 目标选「另存为 PDF」→ 得到分页正确的 PDF
6. 或点 **「下载 HTML」** 导出独立阅读版文件

## 目录结构

```
xhs-export-extension/
├── manifest.json            # MV3；host 仅 xiaohongshu.com + xhscdn
├── rules.json               # DNR 静态规则：为 xhscdn 图片请求注入 Referer（过防盗链）
└── src/
    ├── content/
    │   ├── main-world-hook.js   # MAIN world，hook fetch/XHR 捕获评论接口
    │   └── content.js           # 隔离世界，监听评论事件 + 响应解析请求
    ├── lib/
    │   ├── note-parser.js       # 读 __INITIAL_STATE__（:undefined→:null 后 JSON.parse）
    │   └── reading-html.js      # 阅读版模板（JS 移植 build_html.py，双出口共用）
    ├── background/
    │   └── service-worker.js    # 下载配图转 dataURL（时效签名地址当场下载）+ 开预览页
    ├── popup/                   # 解析摘要 + 评论/OCR 选项
    └── preview/                 # 预览页：字号/主题切换 + 打印入口 + 下载 HTML
```

## 关键实现事实（与 PRD 决策对应）

- **一份模板三个出口**：`reading-html.js` 同时服务预览 / 下载 HTML / 打印 PDF，EPUB（M2）复用同一 `buildBody`；
- **PDF 不用 PDF 库**：`window.print()` + `@page{size:A4;margin:18mm 16mm}` + `@media print`（figure/blockquote 禁跨页、h1 后不分页），文字可选中；
- **图片防盗链**：background 用 DNR 静态规则给 `||xhscdn.com` 请求注入 `Referer: https://www.xiaohongshu.com/`；
- **不规则图片**：默认宽度归一 `width:100%`；高宽比 > 1.8 的长图加 `.tall`（宽度自适应 + 高度上限居中，打印时 200mm）；
- **评论两层同构 JSON**：主楼 `/comment/page`、楼中楼 `/comment/sub`（按 `comment_id` 挂靠），热评优先排序，主楼上限 200、楼中楼每楼 5 条；只收页面已加载的评论；
- **OCR 出口已预留**：模板支持 `img.ocrText` 渲染为图下 blockquote，弹窗选项置灰标「M3 提供」。

## M1 验收清单

- [ ] 加载扩展后无报错（扩展页无红字）
- [ ] 非笔记页打开弹窗显示引导文案
- [ ] 图文笔记页弹窗正确显示标题/作者/字数/配图数/话题数
- [ ] 视频笔记弹窗提示「M1 暂不支持」
- [ ] 不勾评论 → 预览无评论区；先滚动加载评论再勾选 → 预览出现「评论」独立章节且热评在前
- [ ] 预览页图片全部显示（若个别显示「获取失败」提示，记录 URL 反馈）
- [ ] 字号 A−/A+ 生效且刷新后保持；三种主题切换生效且刷新后保持
- [ ] Cmd+P → 另存 PDF：图片不跨页截断、无长图溢出、无工具栏混入、文字可选中
- [ ] 下载的 HTML 独立打开样式完整

## 已知边界（按计划属于后续里程碑）

- EPUB 导出：M2（数据模型已按「一本 EPUB = 1..n 篇笔记」预留）
- OCR 图文识别：M3（onnxruntime-web + PP-OCR 移动端模型；水印碎片段过滤）
- 评论配图（压 800px、每楼 ≤4 张）、语音「[语音 x″]」占位：M2
- `:undefined` 替换为 `:null` 的粗暴做法可能误伤包含字面 `:undefined` 的正文（概率极低，出现时会在控制台有 JSON 解析警告）
- xhscdn 若校验 `Origin` 头（目前判断只校验 Referer，待真机确认），图片下载会失败并在预览中跳过
