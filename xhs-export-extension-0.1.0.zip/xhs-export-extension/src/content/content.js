/**
 * 隔离世界 content script。
 * 监听 MAIN world 转发来的评论 / feed 事件，并在 popup 请求时解析笔记。
 */
(() => {
  const commentsRaw = [];
  const feedRaw = [];
  let lastNoteId = null;

  // buffers 上限：feed 响应大（整卡数据），comment 响应小；超限丢最旧
  const MAX_FEED_RESPONSES = 12;
  const MAX_COMMENT_RESPONSES = 120;

  function pushCapped(buf, item, max) {
    buf.push(item);
    if (buf.length > max) buf.splice(0, buf.length - max);
  }

  document.addEventListener('xhs-export:comment', (e) => {
    try {
      pushCapped(commentsRaw, JSON.parse(e.detail), MAX_COMMENT_RESPONSES);
    } catch (err) {
      /* 忽略坏数据 */
    }
  });

  document.addEventListener('xhs-export:feed', (e) => {
    try {
      pushCapped(feedRaw, JSON.parse(e.detail), MAX_FEED_RESPONSES);
    } catch (err) {
      /* 忽略坏数据 */
    }
  });

  /** 切帖修剪：进入新笔记时丢掉其他笔记的评论缓冲，防止长会话累积
   *  （内存 + 导出过滤开销）。feed 响应 URL 无 note_id，保留最近几条
   *  供取数（取数侧按精确匹配 + 最新优先）。 */
  function pruneBuffers() {
    const m = location.pathname.match(/\/(?:explore|discovery\/item)\/([0-9a-f]+)/);
    const nid = m && m[1];
    if (!nid || nid === lastNoteId) return;
    lastNoteId = nid;
    for (let i = commentsRaw.length - 1; i >= 0; i--) {
      let keep = false;
      try {
        keep =
          new URL(commentsRaw[i].url, location.href).searchParams.get('note_id') === nid;
      } catch (e) {}
      if (!keep) commentsRaw.splice(i, 1);
    }
    if (feedRaw.length > MAX_FEED_RESPONSES) {
      feedRaw.splice(0, feedRaw.length - MAX_FEED_RESPONSES);
    }
  }
  setInterval(pruneBuffers, 1500);
  pruneBuffers();

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.type !== 'XHS_EXTRACT') return;
    // DOM 兜底采集：页面可见但网络未捕获的评论/回复（SPA 内存复用渲染
    // 场景不发请求，网络捕获天然覆盖不到）。失败不影响主流程。
    let domRaw = null;
    try {
      domRaw =
        window.XhsDomComments && window.XhsDomComments.extract
          ? window.XhsDomComments.extract()
          : null;
    } catch (err) {
      console.warn('[小红书导出] DOM 采集失败（跳过兜底）：', err && err.message);
    }
    // parseNote 含同源 fetch 兜底，是异步的：需返回 true 保持通道打开
    window.XhsNoteParser
      .parseNote({ commentsRaw, feedRaw, domRaw })
      .then((result) => sendResponse(result))
      .catch((err) => {
        sendResponse({ ok: false, error: '解析异常：' + (err && err.message) });
      });
    return true;
  });
})();
