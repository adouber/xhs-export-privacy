/**
 * MAIN world 注入脚本（document_start）。
 * 职责：
 *  1. hook 页面的 fetch / XHR，捕获评论接口与 feed 接口的响应：
 *     - 评论（页面滚动加载评论时自动收集）：
 *       主楼 /api/sns/web/v2/comment/page?note_id=...
 *       楼中楼 /api/sns/web/v2/comment/sub?comment_id=...
 *       → 事件 xhs-export:comment
 *     - 笔记数据（登录态页面笔记由前端异步调 POST /api/sns/web/v1/feed
 *       获取，不进 INITIAL_STATE）：
 *       → 事件 xhs-export:feed
 *  2. 通过 DOM CustomEvent 把捕获结果转发给隔离世界的 content script
 *     （MAIN 与 ISOLATED 世界不共享 window，只能借 DOM 事件桥接）。
 */
(() => {
  if (window.__xhsExportHookInstalled) return;
  window.__xhsExportHookInstalled = true;

  // 版本号不锁死 v2：接口升到 v3/v4 时仍能捕获（2026-09 真机观察到楼中楼
  // 随下拉自动展开加载，若此处匹配不上会整类响应静默丢失）
  const COMMENT_URL_RE = /\/api\/sns\/web\/v\d+\/comment/;
  const FEED_URL_RE = /\/api\/sns\/web\/v1\/feed/;

  /** URL 是否属于我们关心的接口（评论或 feed）。 */
  function isCapturedUrl(url) {
    const u = String(url || '');
    return COMMENT_URL_RE.test(u) || FEED_URL_RE.test(u);
  }

  /** URL 对应的转发事件名。 */
  function eventNameForUrl(url) {
    return COMMENT_URL_RE.test(String(url || ''))
      ? 'xhs-export:comment'
      : 'xhs-export:feed';
  }

  function forward(url, json, eventName) {
    try {
      document.dispatchEvent(
        new CustomEvent(eventName, {
          detail: JSON.stringify({ url: String(url), json }),
        })
      );
    } catch (e) {
      /* 忽略转发失败 */
    }
  }

  // ---- fetch hook ----
  const origFetch = window.fetch;
  if (typeof origFetch === 'function') {
    window.fetch = function (...args) {
      const url =
        typeof args[0] === 'string'
          ? args[0]
          : (args[0] && args[0].url) || '';
      const p = origFetch.apply(this, args);
      if (isCapturedUrl(url)) {
        const evName = eventNameForUrl(url);
        p.then((res) => {
          try {
            res
              .clone()
              .json()
              .then((json) => forward(url, json, evName))
              .catch(() => {});
          } catch (e) {}
        }).catch(() => {});
      }
      return p;
    };
  }

  // ---- XHR hook ----
  const OrigOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__xhsExportUrl = String(url || '');
    return OrigOpen.call(this, method, url, ...rest);
  };
  const OrigSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...args) {
    if (isCapturedUrl(this.__xhsExportUrl || '')) {
      const evName = eventNameForUrl(this.__xhsExportUrl);
      this.addEventListener('load', () => {
        try {
          forward(this.__xhsExportUrl, JSON.parse(this.responseText), evName);
        } catch (e) {}
      });
    }
    return OrigSend.apply(this, args);
  };
})();
