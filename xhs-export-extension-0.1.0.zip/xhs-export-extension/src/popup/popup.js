/** Popup：解析摘要 + 选项 + 触发导出。 */
const NOTE_PAGE_RE = /^https:\/\/www\.xiaohongshu\.com\/(?:explore|discovery\/item)\//;

let currentNote = null;

const el = (id) => document.getElementById(id);

function showPanel(show) {
  el('hint').classList.toggle('hidden', show);
  el('panel').classList.toggle('hidden', !show);
}

function fmtInt(n) {
  return typeof n === 'number' ? n.toLocaleString('zh-CN') : String(n || 0);
}

function renderSummary(result) {
  const box = el('summary');
  if (!result || !result.ok) {
    box.innerHTML = '<div class="err">' + escapeHtml((result && result.error) || '解析失败') + '</div>';
    el('export-btn').disabled = true;
    return;
  }
  currentNote = result.note;
  const n = result.note;
  const charCount = (n.desc || '').replace(/\s/g, '').length;
  box.innerHTML = [
    '<h2>' + (escapeHtml(n.title) || '(无标题笔记)') + '</h2>',
    '<div class="row">作者：' + escapeHtml(n.author || '未知') + '</div>',
    '<div class="row">正文 ' + fmtInt(charCount) + ' 字 · 配图 ' + n.images.length +
      ' 张 · 话题 ' + n.tags.length + ' 个</div>',
    '<div class="row">评论：主楼 ' + fmtInt(n.comments.total) + ' 条 · 楼中楼 ' +
      fmtInt(n.comments.subsTotal || 0) + ' 条' +
      (n.comments.pageTotal ? '（页面角标 ' + fmtInt(Number(n.comments.pageTotal)) + '，含回复）' : '') + '</div>',
    result.warning ? '<div class="warn">' + escapeHtml(result.warning) + '</div>' : '',
    n.images.length === 0 ? '<div class="warn">该笔记没有配图。</div>' : '',
  ].join('');
}

function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

async function extract() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !NOTE_PAGE_RE.test(tab.url || '')) {
    showPanel(false);
    return;
  }
  showPanel(true);

  try {
    const result = await chrome.tabs.sendMessage(tab.id, { type: 'XHS_EXTRACT' });
    renderSummary(result);
  } catch (e) {
    renderSummary({
      ok: false,
      error:
        '无法连接页面脚本。如果刚安装/更新了扩展，请刷新笔记页后重新打开弹窗。',
    });
  }
}

el('export-btn').addEventListener('click', async () => {
  if (!currentNote) return;
  const btn = el('export-btn');
  const status = el('status');
  btn.disabled = true;
  status.className = 'status';
  status.textContent = '正在下载配图（图片是时效签名地址，必须当场下载）…';

  try {
    const resp = await chrome.runtime.sendMessage({
      type: 'XHS_EXPORT',
      note: currentNote,
      options: {
        includeComments: el('opt-comments').checked,
      },
    });
    if (!resp || !resp.ok) {
      throw new Error((resp && resp.error) || '导出失败');
    }
    status.textContent =
      '完成：' + resp.imageCount + ' 张配图' +
      (resp.imageFailed ? '（' + resp.imageFailed + ' 张失败，预览中将跳过）' : '') +
      '，预览页已在新标签页打开。';
  } catch (e) {
    status.className = 'status err';
    status.textContent = '导出失败：' + e.message;
  } finally {
    btn.disabled = false;
  }
});

extract();
