/**
 * 预览页：读取 storage 里的 payload → 用共享模板渲染 → 字号/主题切换 + 打印 + 下载 HTML。
 * 「按页预览」即打印入口（window.print），PDF 走打印流（文字可选中）。
 */
(async () => {
  const FONT_KEY = 'xhsExportFontSize';

  const el = (id) => document.getElementById(id);
  const content = el('content');

  const { exportPayload } = await chrome.storage.local.get('exportPayload');
  if (!exportPayload || !exportPayload.note) {
    content.innerHTML =
      '<p class="placeholder err">没有找到导出数据。请回到笔记页，从扩展弹窗重新「生成阅读版预览」。</p>';
    return;
  }

  const note = exportPayload.note;

  // 注入共享阅读版样式
  const style = document.createElement('style');
  style.textContent = window.XhsReadingHtml.getCss();
  document.head.appendChild(style);

  document.title = (note.title || '阅读版') + ' · 阅读版预览';
  el('tb-title').textContent = note.title || '(无标题笔记)';
  el('tb-title').title = note.title || '';

  const failed = (note.images || []).filter((i) => !i.dataUrl).length;
  const meta = [
    note.author,
    (note.images || []).length + ' 张配图',
    note.comments && note.comments.list.length
      ? '评论 ' + note.comments.list.length + ' 条'
      : '',
    exportPayload.imageFailed ? failed + ' 张图片获取失败已跳过' : '',
  ]
    .filter(Boolean)
    .join(' · ');
  el('tb-meta').textContent = meta;

  content.innerHTML = window.XhsReadingHtml.buildBody(note);

  // ---- 字号 ----
  let fontSize = parseInt(localStorage.getItem(FONT_KEY) || '17', 10);
  const applyFont = () => {
    fontSize = Math.min(24, Math.max(13, fontSize));
    content.style.fontSize = fontSize + 'px';
    localStorage.setItem(FONT_KEY, String(fontSize));
  };
  el('font-minus').addEventListener('click', () => { fontSize -= 1; applyFont(); });
  el('font-plus').addEventListener('click', () => { fontSize += 1; applyFont(); });
  applyFont();

  // ---- OCR（M3：worker 内跑 PP-OCRv4，结果可校对，回写 note.images[i].ocrText）----
  let ocrWorker = null;
  let ocrReady = null; // Promise<void>

  function getOcrWorker() {
    if (ocrWorker) return ocrWorker;
    ocrWorker = new Worker(chrome.runtime.getURL('src/ocr/ocr-worker.js'), { type: 'module' });
    ocrReady = new Promise((resolve, reject) => {
      const onMsg = (e) => {
        const m = e.data || {};
        if (m.type === 'ready') { cleanup(); resolve(); }
        else if (m.type === 'initError') { cleanup(); reject(new Error(m.error)); }
      };
      const onErr = (e) => { cleanup(); reject(new Error('OCR worker 加载失败：' + (e.message || e.type))); };
      const cleanup = () => {
        ocrWorker.removeEventListener('message', onMsg);
        ocrWorker.removeEventListener('error', onErr);
      };
      ocrWorker.addEventListener('message', onMsg);
      ocrWorker.addEventListener('error', onErr);
    });
    ocrReady.catch(() => {}); // 避免未处理 rejection
    ocrWorker.postMessage({ type: 'init', baseUrl: chrome.runtime.getURL('/') });
    return ocrWorker;
  }

  function ocrOne(dataUrl) {
    const worker = getOcrWorker();
    return new Promise((resolve, reject) => {
      const id = Math.random().toString(36).slice(2);
      const onMsg = (e) => {
        const m = e.data || {};
        if (m.id !== id) return;
        worker.removeEventListener('message', onMsg);
        if (m.type === 'ocrDone') resolve(m.lines);
        else if (m.type === 'ocrError') reject(new Error(m.error));
      };
      worker.addEventListener('message', onMsg);
      worker.postMessage({ type: 'ocr', id, dataUrl });
    });
  }

  /** 视频笔记不做 OCR：唯一"配图"是视频封面帧，识别出的字幕碎片无阅读价值。 */
  function isVideoNote() {
    return note.type === 'video' || note.degraded === 'video';
  }

  /** 按钮态：全部有效配图都有文字 → 「重新识别全部」（点击带确认）；否则「OCR 识别」。 */
  function updateOcrButtonLabel() {
    const btn = el('ocr');
    if (btn.disabled) return;
    const all = (note.images || []).filter((im) => im.dataUrl);
    const missing = all.filter((im) => !(im.ocrText && im.ocrText.trim())).length;
    btn.textContent = all.length && missing === 0 ? '重新识别全部' : 'OCR 识别';
  }

  /** 跑 OCR。默认只跑还没有文字的图（失败的重跑、成功的跳过、校对结果保留）；
   *  force=true 时全量重跑（按钮「重新识别全部」+确认后才会走到这）。 */
  async function runOcrOnImages(force) {
    if (isVideoNote()) {
      showToast('视频笔记不做 OCR（封面是视频帧，无识别价值）', { timeout: 3500 });
      return;
    }
    const all = [];
    (note.images || []).forEach((img, i) => {
      if (img.dataUrl) all.push({ img, i });
    });
    if (!all.length) {
      showToast('这篇笔记没有可识别的配图', { timeout: 3000 });
      return;
    }
    const targets = force ? all : all.filter(({ img }) => !(img.ocrText && img.ocrText.trim()));
    if (!targets.length) {
      showToast('全部配图都已有识别文字。如需全部重跑，请点「重新识别全部」', { timeout: 3500 });
      return;
    }
    const skipped = all.length - targets.length;
    const btn = el('ocr');
    btn.disabled = true;
    btn.textContent = 'OCR 中…';
    const toast = showToast('OCR 初始化中（首次需加载模型，约十几 MB）…');
    let failed = 0;
    try {
      await ocrReady;
      for (let k = 0; k < targets.length; k++) {
        const { img, i } = targets[k];
        toast.textContent = 'OCR 识别中 ' + (k + 1) + '/' + targets.length + ' 张…';
        try {
          const lines = await ocrOne(img.dataUrl);
          img.ocrText = lines.map((l) => l.text).join('\n');
          const quote = content.querySelector('blockquote.ocr-text[data-img="' + i + '"]');
          if (quote) quote.textContent = img.ocrText;
        } catch (e) {
          failed += 1;
          console.warn('[小红书导出] OCR 单图失败：', e);
        }
      }
      // 依识别结果判定笔记形态并重渲染（总是重渲染：图文结合模式下首次 OCR 完成也要让 OCR 章节出现）。
      // 自动判定只定默认值，用户可在工具栏「版式」下拉随时切换。
      const core = window.XhsOcrCore;
      if (core) {
        note.ocrMode = core.classifyOcrMode(
          note.desc,
          (note.images || []).map((im) => im.ocrText)
        );
        content.innerHTML = window.XhsReadingHtml.buildBody(note);
        syncOcrModeSelect();
      }
      toast.remove();
      const modeLabel = note.ocrMode === 'longform' ? '，已按「合并长文」排版，可用工具栏下拉切回图文结合' : '';
      showToast(
        'OCR 完成：' + (targets.length - failed) + '/' + targets.length + ' 张成功' +
        (skipped ? '（跳过已有文字 ' + skipped + ' 张，校对结果保留）' : '') +
        (failed ? '，失败的可再点按钮重跑' : modeLabel + '，文字可点击校对'),
        failed ? { timeout: 5000 } : { type: 'ok', timeout: 4500 }
      );
    } catch (e) {
      toast.remove();
      showToast('OCR 初始化失败：' + e.message, { type: 'err', timeout: 6000 });
    } finally {
      btn.disabled = false;
      updateOcrButtonLabel();
    }
  }

  // 校对：编辑 OCR 文字实时回写 note（后续导出 HTML/EPUB 用的就是改后的文本）
  content.addEventListener('input', (e) => {
    const t = e.target;
    if (t && t.matches && t.matches('blockquote.ocr-text[data-img]')) {
      const i = Number(t.getAttribute('data-img'));
      if (note.images && note.images[i]) note.images[i].ocrText = t.textContent;
    }
  });

  // ---- 版式切换：OCR 识别出文字后出现；「合并长文」/「图文结合」即时重排，导出跟随当前版式 ----
  function syncOcrModeSelect() {
    const sel = el('ocr-mode');
    const hasText = (note.images || []).some((im) => im.ocrText && im.ocrText.trim());
    const mode = note.ocrMode === 'longform' ? 'longform' : 'interleaved';
    sel.classList.toggle('hidden', !hasText);
    if (!hasText) return;
    sel.innerHTML =
      '<option value="longform">版式：合并长文</option>' +
      '<option value="interleaved">版式：图文结合</option>';
    sel.value = mode;
  }

  el('ocr-mode').addEventListener('change', () => {
    const v = el('ocr-mode').value;
    if (v === note.ocrMode) return;
    note.ocrMode = v;
    content.innerHTML = window.XhsReadingHtml.buildBody(note);
    const label = v === 'longform' ? '合并长文' : '图文结合';
    showToast('已切换为「' + label + '」版式，导出 HTML/EPUB 将使用此版式', { timeout: 3000 });
  });

  el('ocr').addEventListener('click', () => {
    const all = (note.images || []).filter((im) => im.dataUrl);
    const missing = all.filter((im) => !(im.ocrText && im.ocrText.trim())).length;
    if (all.length && missing === 0) {
      // 全部识别过：全量重跑会覆盖校对成果，先确认
      if (!confirm('全部配图都已识别过。重新识别将覆盖现有文字（包括你的校对修改），确定继续？')) return;
      runOcrOnImages(true);
    } else {
      runOcrOnImages(false);
    }
  });
  if (isVideoNote()) {
    el('ocr').disabled = true;
    el('ocr').title = '视频笔记不做 OCR（封面是视频帧）';
  }
  updateOcrButtonLabel();

  // ---- 主题：跟随系统深色/浅色（prefers-color-scheme），见 preview.css；无手动切换 ----

  // ---- 打印（PDF 出口）----
  el('print').addEventListener('click', () => window.print());

  // ---- 下载 HTML（阅读版出口，与预览同一模板）----
  el('download').addEventListener('click', () => {
    const html = window.XhsReadingHtml.buildFullHtml(note);
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (note.title || '小红书笔记').replace(/[\\/:*?"<>|]/g, '_') + '.html';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  });

  // ---- 轻量 toast：异步操作（EPUB 打包）的过程/结果反馈 ----
  function showToast(text, opts) {
    const { type = '', timeout = 0 } = opts || {};
    const t = document.createElement('div');
    t.className = 'toast' + (type ? ' ' + type : '');
    t.textContent = text;
    document.body.appendChild(t);
    if (timeout > 0) setTimeout(() => t.remove(), timeout);
    return t;
  }

  // ---- 导出 EPUB（M2 出口：同一笔记数据 → EPUB 3 包）----
  el('epub').addEventListener('click', async () => {
    const btn = el('epub');
    if (btn.disabled) return; // 防重复点击
    btn.disabled = true;
    const prevLabel = btn.textContent;
    btn.textContent = '打包中…';
    const toast = showToast('正在打包 EPUB…（图片越多耗时越久）');
    // 让按钮态/toast 先完成渲染，再进入打包（否则同步构建会吞掉首帧反馈）
    await new Promise((r) => setTimeout(r, 50));
    const start = Date.now();
    const tick = setInterval(() => {
      toast.textContent = '正在打包 EPUB…（已进行 ' + Math.round((Date.now() - start) / 1000) + ' 秒）';
    }, 500);
    try {
      const blob = await window.XhsEpubBuilder.buildEpubBlob({ notes: [note] });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = (note.title || '小红书笔记').replace(/[\\/:*?"<>|]/g, '_') + '.epub';
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      toast.remove();
      showToast(
        'EPUB 已生成（' + Math.max(1, Math.round(blob.size / 1024)) + ' KB），已开始下载',
        { type: 'ok', timeout: 4000 }
      );
    } catch (e) {
      console.error('[小红书导出] EPUB 打包失败：', e);
      toast.remove();
      showToast('EPUB 打包失败：' + (e && e.message ? e.message : e), { type: 'err', timeout: 6000 });
    } finally {
      clearInterval(tick);
      btn.disabled = false;
      btn.textContent = prevLabel;
    }
  });
})();
