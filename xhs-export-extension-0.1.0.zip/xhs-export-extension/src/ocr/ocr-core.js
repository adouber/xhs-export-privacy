/**
 * OCR 核心算法（纯 JS，无 DOM/Node 依赖；Node 测试与浏览器 Worker 共用）。
 * 对应 RapidOCR/PP-OCRv4 mobile 三模型管线：
 *   det（DBNet 文本检测）→ rec（CRNN+CTC 识别）→（cls 方向分类暂缓，MVP 假定图片正向）
 * 模型输入约定：
 *   det: [1,3,H,W] float32，H/W 为 32 的倍数；归一化 mean=[0.485,0.456,0.406] std=[0.229,0.224,0.225]
 *   rec: [1,3,48,W] float32（W≤320，右侧 zero-pad 到 320）
 * 字典（ppocr_keys_v1.txt 6622 行）CTC 词表 = [blank] + 字典 + [空格]，共 6624 类。
 */
(() => {
  const DET_MEAN = [0.485, 0.456, 0.406];
  const DET_STD = [0.229, 0.224, 0.225];
  const REC_H = 48;
  const REC_W = 320;

  /* ------------------------------------------------ det 预处理 */

  /** det 输入尺寸：min 边 ≥ limit（不足则放大），两边向上取整到 32 的倍数。 */
  function detResizeDim(w, h, limitSide) {
    const limit = limitSide || 736;
    const ratio = Math.max(1, limit / Math.min(w, h));
    let dw = Math.ceil((w * ratio) / 32) * 32;
    let dh = Math.ceil((h * ratio) / 32) * 32;
    return { width: dw, height: dh, ratio };
  }

  /** RGBA(Uint8ClampedArray, w, h) → 缩放双线性采样到 (dw, dh) → NCHW float32 归一化。 */
  function rgbaToDetTensor(src, sw, sh, dw, dh) {
    const out = new Float32Array(3 * dw * dh);
    const plane = dw * dh;
    for (let y = 0; y < dh; y++) {
      const sy = Math.min(sh - 1, Math.max(0, ((y + 0.5) * sh) / dh - 0.5));
      const y0 = Math.floor(sy);
      const y1 = Math.min(sh - 1, y0 + 1);
      const fy = sy - y0;
      for (let x = 0; x < dw; x++) {
        const sx = Math.min(sw - 1, Math.max(0, ((x + 0.5) * sw) / dw - 0.5));
        const x0 = Math.floor(sx);
        const x1 = Math.min(sw - 1, x0 + 1);
        const fx = sx - x0;
        const i00 = (y0 * sw + x0) * 4;
        const i01 = (y0 * sw + x1) * 4;
        const i10 = (y1 * sw + x0) * 4;
        const i11 = (y1 * sw + x1) * 4;
        const o = y * dw + x;
        for (let c = 0; c < 3; c++) {
          const v =
            src[i00 + c] * (1 - fx) * (1 - fy) +
            src[i01 + c] * fx * (1 - fy) +
            src[i10 + c] * (1 - fx) * fy +
            src[i11 + c] * fx * fy;
          out[c * plane + o] = (v / 255 - DET_MEAN[c]) / DET_STD[c];
        }
      }
    }
    return out;
  }

  /* ------------------------------------------------ det 后处理（DB，简化 AABB 版） */

  /**
   * DB 概率图 → 文本框（原图坐标）。
   * @param prob Float32Array [H*W]，det 输出概率图
   * @param pw, ph 概率图尺寸
   * @param ow, oh 原图尺寸
   * @returns [{x0,y0,x1,y1,score}] 按上→下、左→右排序
   */
  function dbPostprocess(prob, pw, ph, ow, oh, opts) {
    const o = Object.assign({ thresh: 0.3, boxThresh: 0.55, unclipRatio: 1.6, minSide: 3 }, opts);
    const bin = new Uint8Array(pw * ph);
    for (let i = 0; i < bin.length; i++) bin[i] = prob[i] > o.thresh ? 1 : 0;

    // 两遍扫描连通域（4 邻接，union-find）
    const labels = new Int32Array(pw * ph).fill(-1);
    const parent = [];
    function find(a) {
      while (parent[a] !== a) {
        parent[a] = parent[parent[a]];
        a = parent[a];
      }
      return a;
    }
    function union(a, b) {
      const ra = find(a);
      const rb = find(b);
      if (ra !== rb) parent[rb] = ra;
    }
    let next = 0;
    for (let y = 0; y < ph; y++) {
      for (let x = 0; x < pw; x++) {
        const i = y * pw + x;
        if (!bin[i]) continue;
        const up = y > 0 ? labels[i - pw] : -1;
        const left = x > 0 ? labels[i - 1] : -1;
        if (up < 0 && left < 0) {
          parent[next] = next;
          labels[i] = next++;
        } else if (up >= 0 && left < 0) {
          labels[i] = up;
        } else if (up < 0 && left >= 0) {
          labels[i] = left;
        } else {
          labels[i] = Math.min(up, left);
          if (up !== left) union(up, left);
        }
      }
    }

    // 汇总每个连通域：bbox + 概率和/计数
    const boxes = new Map(); // root -> {minx,miny,maxx,maxy,sum,cnt}
    for (let y = 0; y < ph; y++) {
      for (let x = 0; x < pw; x++) {
        const i = y * pw + x;
        const l = labels[i];
        if (l < 0) continue;
        const r = find(l);
        let b = boxes.get(r);
        if (!b) {
          b = { minx: x, miny: y, maxx: x, maxy: y, sum: 0, cnt: 0 };
          boxes.set(r, b);
        }
        if (x < b.minx) b.minx = x;
        if (x > b.maxx) b.maxx = x;
        if (y < b.miny) b.miny = y;
        if (y > b.maxy) b.maxy = y;
        b.sum += prob[i];
        b.cnt += 1;
      }
    }

    const kx = ow / pw;
    const ky = oh / ph;
    const result = [];
    for (const b of boxes.values()) {
      const w = b.maxx - b.minx + 1;
      const h = b.maxy - b.miny + 1;
      if (w < o.minSide || h < o.minSide) continue;
      const score = b.sum / b.cnt;
      if (score < o.boxThresh) continue;
      // DB unclip 简化版：按 area/perimeter 外扩
      const offset = (w * h * o.unclipRatio) / (2 * (w + h));
      let x0 = Math.max(0, b.minx - offset);
      let y0 = Math.max(0, b.miny - offset);
      let x1 = Math.min(pw - 1, b.maxx + offset);
      let y1 = Math.min(ph - 1, b.maxy + offset);
      result.push({
        x0: Math.round(x0 * kx),
        y0: Math.round(y0 * ky),
        x1: Math.round((x1 + 1) * kx),
        y1: Math.round((y1 + 1) * ky),
        score: Math.round(score * 1000) / 1000,
      });
    }
    // 阅读顺序：上→下（按行容差分桶），同桶内左→右
    result.sort((a, b2) => {
      const ay = a.y0 + a.y1;
      const by = b2.y0 + b2.y1;
      const tol = Math.max(a.y1 - a.y0, b2.y1 - b2.y0) * 0.6;
      if (Math.abs(ay - by) <= tol) return a.x0 - b2.x0;
      return ay - by;
    });
    return result;
  }

  /* ------------------------------------------------ rec 预处理 */

  /** 从原图 RGBA 裁 box（box 越界自动钳制），双线性缩放到 48×w'，再 zero-pad 到 320，返回 NCHW。 */
  function cropToRecTensor(src, sw, sh, box) {
    const bx0 = Math.max(0, Math.min(sw - 1, box.x0));
    const by0 = Math.max(0, Math.min(sh - 1, box.y0));
    const bx1 = Math.max(bx0 + 1, Math.min(sw, box.x1));
    const by1 = Math.max(by0 + 1, Math.min(sh, box.y1));
    const bw = bx1 - bx0;
    const bh = by1 - by0;
    let rw = Math.ceil((bw * REC_H) / bh);
    if (rw < 8) rw = 8;
    if (rw > REC_W) rw = REC_W;

    const plane = REC_H * REC_W;
    const out = new Float32Array(3 * plane); // 右侧 pad 区保持 0（归一化后的黑）
    for (let y = 0; y < REC_H; y++) {
      const sy = Math.min(bh - 1, Math.max(0, ((y + 0.5) * bh) / REC_H - 0.5));
      const sy0 = Math.floor(by0 + sy);
      const sy1 = Math.min(by1 - 1, sy0 + 1);
      const fy = sy - Math.floor(sy);
      for (let x = 0; x < rw; x++) {
        const sx = Math.min(bw - 1, Math.max(0, ((x + 0.5) * bw) / rw - 0.5));
        const sx0 = Math.floor(bx0 + sx);
        const sx1 = Math.min(bx1 - 1, sx0 + 1);
        const fx = sx - Math.floor(sx);
        const i00 = (sy0 * sw + sx0) * 4;
        const i01 = (sy0 * sw + sx1) * 4;
        const i10 = (sy1 * sw + sx0) * 4;
        const i11 = (sy1 * sw + sx1) * 4;
        const o = y * REC_W + x;
        for (let c = 0; c < 3; c++) {
          const v =
            src[i00 + c] * (1 - fx) * (1 - fy) +
            src[i01 + c] * fx * (1 - fy) +
            src[i10 + c] * (1 - fx) * fy +
            src[i11 + c] * fx * fy;
          out[c * plane + o] = (v / 255 - DET_MEAN[c]) / DET_STD[c];
        }
      }
    }
    return out;
  }

  /* ------------------------------------------------ CTC 解码 */

  /** 从字典文本构建词表：[blank] + 字典行 + [空格]（PaddleOCR CTCLabelDecode 口径）。 */
  function buildCharset(dictText) {
    const chars = dictText.split('\n').map((s) => s.replace(/\r$/, '')).filter((s) => s.length > 0);
    return ['<blank>', ...chars, ' '];
  }

  /** 贪心 CTC：逐帧 argmax，去重、去 blank；返回 {text, meanScore}。 */
  function ctcDecode(logits, numClasses, charset) {
    const T = logits.length / numClasses;
    let text = '';
    let prev = -1;
    let scoreSum = 0;
    for (let t = 0; t < T; t++) {
      const base = t * numClasses;
      let best = 0;
      let bestV = -Infinity;
      for (let c = 0; c < numClasses; c++) {
        if (logits[base + c] > bestV) {
          bestV = logits[base + c];
          best = c;
        }
      }
      scoreSum += bestV;
      if (best !== 0 && best !== prev) text += charset[best] || '';
      prev = best;
    }
    return { text, meanScore: T ? scoreSum / T : 0 };
  }

  /* ------------------------------------------------ 水印过滤（HANDOFF：水印碎片段需过滤） */

  const WM_PATTERNS = [
    /小红书号/,                     // 站方水印「小红书号：xxx」
    /^小红书小红书$/,               // 水印重复打点碎片
    /^(?:间辩|小会|特意|分享|收藏|点赞|关注)+$/, // 水印碎字（HANDOFF 实测样本）
  ];

  /** 单行是否疑似水印/碎片。 */
  function isWatermark(text, score, opts) {
    const o = Object.assign({ minScore: 0.5, minLen: 1 }, opts);
    if (!text) return true;
    if (text.trim().length < o.minLen) return true;
    if (score < o.minScore) return true;
    for (const p of WM_PATTERNS) if (p.test(text.trim())) return true;
    return false;
  }

  /* ------------------------------------------------ OCR 模式分类（图多的三种形态） */

  /**
   * 依 OCR 结果区分笔记形态，驱动渲染策略：
   *  - longform    纯文字长图（文章拆成图）：文字合并连续阅读，原图收纳文末
   *  - interleaved 图文交叉：文字块跟在对应图下（现状）
   *  - none        纯图片：识别不出文字，不加文字块
   * @param desc 笔记正文
   * @param ocrTexts 每张配图的 ocrText 数组（可为空串）
   */
  function classifyOcrMode(desc, ocrTexts, opts) {
    const o = Object.assign({ textImgMinChars: 150, longformOcrMin: 200, minMeaningful: 20 }, opts);
    const texts = (ocrTexts || []).map((t) => String(t || '').replace(/\s/g, ''));
    const descChars = String(desc || '').replace(/\s/g, '').length;
    const textImgs = texts.filter((t) => t.length >= o.textImgMinChars);
    const ocrChars = textImgs.reduce((a, b) => a + b.length, 0);

    if (textImgs.length >= 2) return 'longform'; // 文章拆成多张图
    if (textImgs.length === 1 && ocrChars >= o.longformOcrMin && ocrChars > descChars * 2) {
      return 'longform'; // 单张长图承载全文，正文几乎为空
    }
    // 有「有效」文字才算图文交叉——零星水印残留（<minMeaningful 字）视为纯图片
    if (texts.some((t) => t.length >= o.minMeaningful)) return 'interleaved';
    return 'none';
  }

  const api = {
    detResizeDim,
    rgbaToDetTensor,
    dbPostprocess,
    cropToRecTensor,
    buildCharset,
    ctcDecode,
    isWatermark,
    classifyOcrMode,
    DET_MEAN,
    DET_STD,
    REC_H,
    REC_W,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof self !== 'undefined') self.XhsOcrCore = api;
  if (typeof window !== 'undefined') window.XhsOcrCore = api;
})();
