/**
 * OCR Worker（module worker）：onnxruntime-web wasm 后端跑 PP-OCRv4 mobile。
 * - 算法（det 后处理 / rec 预处理 / CTC 解码 / 水印过滤）复用 src/ocr/ocr-core.js，
 *   与 Node 端 ground-truth 管线（tools/ocr-node-check.mjs）同一份代码。
 * - 模型路径由主线程传入（扩展页负责 chrome.runtime.getURL）。
 * 协议：
 *   → { type:'init', baseUrl }        初始化（加载 det/rec session）
 *   ← { type:'ready' } | { type:'initError', error }
 *   → { type:'ocr', id, dataUrl }     识别一张图
 *   ← { type:'ocrDone', id, lines:[{text,score}], ms } | { type:'ocrError', id, error }
 */
import * as ort from '../../vendor/ort/ort.wasm.min.mjs';
import './ocr-core.js';

const core = self.XhsOcrCore;
let detSession = null;
let recSession = null;
let charset = null;

async function fetchBuffer(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error('模型加载失败 HTTP ' + res.status + ': ' + url);
  return res.arrayBuffer();
}

async function init(baseUrl) {
  ort.env.wasm.wasmPaths = baseUrl + 'vendor/ort/';
  ort.env.wasm.numThreads = 1; // 扩展页未启用 COOP/COEP 时 SAB 不可靠，单线程足够（det 实测百毫秒级）
  const [detBuf, recBuf, dictText] = await Promise.all([
    fetchBuffer(baseUrl + 'models/ch_PP-OCRv4_det_mobile.onnx'),
    fetchBuffer(baseUrl + 'models/ch_PP-OCRv4_rec_mobile.onnx'),
    fetchBuffer(baseUrl + 'models/ppocr_keys_v1.txt').then((b) => new TextDecoder().decode(b)),
  ]);
  charset = core.buildCharset(dictText);
  detSession = await ort.InferenceSession.create(detBuf, { executionProviders: ['wasm'] });
  recSession = await ort.InferenceSession.create(recBuf, { executionProviders: ['wasm'] });
}

async function decodeImage(dataUrl) {
  const blob = await (await fetch(dataUrl)).blob();
  const bmp = await createImageBitmap(blob);
  const canvas = new OffscreenCanvas(bmp.width, bmp.height);
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(bmp, 0, 0);
  const data = ctx.getImageData(0, 0, bmp.width, bmp.height);
  bmp.close();
  return data;
}

async function runOcr(id, dataUrl) {
  const t0 = Date.now();
  const img = await decodeImage(dataUrl);
  const { width: w, height: h, data: rgba } = img;

  // det
  const dim = core.detResizeDim(w, h, 736);
  const detIn = core.rgbaToDetTensor(rgba, w, h, dim.width, dim.height);
  const detOut = await detSession.run({
    [detSession.inputNames[0]]: new ort.Tensor('float32', detIn, [1, 3, dim.height, dim.width]),
  });
  const prob = detOut[detSession.outputNames[0]].data;
  const boxes = core.dbPostprocess(prob, dim.width, dim.height, w, h);

  // rec（逐框）
  const lines = [];
  for (const box of boxes) {
    const recIn = core.cropToRecTensor(rgba, w, h, box);
    const recOut = await recSession.run({
      [recSession.inputNames[0]]: new ort.Tensor('float32', recIn, [1, 3, core.REC_H, core.REC_W]),
    });
    const logits = recOut[recSession.outputNames[0]].data;
    const T = Math.round(logits.length / charset.length);
    const { text } = core.ctcDecode(logits, charset.length, charset);
    if (core.isWatermark(text, box.score)) continue; // 水印/碎片直接滤掉，减少校对负担
    if (text) lines.push({ text, score: box.score });
  }
  self.postMessage({ type: 'ocrDone', id, lines, ms: Date.now() - t0 });
}

self.addEventListener('message', async (e) => {
  const msg = e.data || {};
  try {
    if (msg.type === 'init') {
      await init(msg.baseUrl);
      self.postMessage({ type: 'ready' });
    } else if (msg.type === 'ocr') {
      await runOcr(msg.id, msg.dataUrl);
    }
  } catch (err) {
    const type = msg.type === 'init' ? 'initError' : 'ocrError';
    self.postMessage({ type, id: msg.id, error: String((err && err.message) || err) });
  }
});
