/**
 * Background service worker（MV3）。
 * 职责：
 *  1. 接收 popup 的 EXPORT 消息，逐张下载配图（DNR 静态规则已为 xhscdn 请求注入 Referer），
 *     转成 dataURL 塞进笔记模型；
 *  2. 把完整 payload 写入 chrome.storage.local（exportPayload）；
 *  3. 新标签页打开预览页。
 */
const PREVIEW_URL = chrome.runtime.getURL('src/preview/preview.html');
const IMAGE_FETCH_TIMEOUT_MS = 15000;

/** Service Worker 里没有 FileReader，用 arrayBuffer 手转 base64。 */
function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunk = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(
      null,
      bytes.subarray(i, i + chunk)
    );
  }
  return btoa(binary);
}

async function fetchAsDataUrl(url) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), IMAGE_FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: ctrl.signal, credentials: 'omit' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const buf = await res.arrayBuffer();
    let type = res.headers.get('content-type') || 'image/jpeg';
    if (!/^image\//.test(type)) type = 'image/jpeg';
    return 'data:' + type + ';base64,' + arrayBufferToBase64(buf);
  } finally {
    clearTimeout(timer);
  }
}

/** 评论配图下载上限：防止长评帖导出时间失控（超出部分如实计数）。 */
const MAX_COMMENT_IMAGES = 100;

/** 逐张下载配图 + 评论图片；失败的保留 url、留空 dataUrl，由预览端降级跳过。
 *  上限只针对真实配图（100 张）；表情/贴纸图是小文件，不占上限、不限量。 */
async function downloadImages(note) {
  let done = 0;
  let failed = 0;

  const noteImgs = note.images || [];
  const commentPics = [];
  const stickers = [];
  for (const c of (note.comments && note.comments.list) || []) {
    for (const p of c.pictures || []) commentPics.push(p);
    for (const st of c.stickers || []) stickers.push(st);
    for (const s of c.subComments || []) {
      for (const p of s.pictures || []) commentPics.push(p);
      for (const st of s.stickers || []) stickers.push(st);
    }
  }
  const capped = Math.max(0, commentPics.length - MAX_COMMENT_IMAGES);
  const picked = commentPics.slice(0, MAX_COMMENT_IMAGES);
  if (capped > 0) {
    console.warn(
      '[小红书导出] 评论配图超出上限 ' + MAX_COMMENT_IMAGES +
      ' 张，' + capped + ' 张未下载（仅文字导出）'
    );
  }

  const total = noteImgs.length + picked.length + stickers.length;
  for (const img of noteImgs.concat(picked, stickers)) {
    try {
      img.dataUrl = await fetchAsDataUrl(img.url);
    } catch (e) {
      failed += 1;
      console.warn('[小红书导出] 图片下载失败：', img.url, e);
    }
    done += 1;
  }
  return {
    failed,
    total,
    commentImageCount: picked.length,
    stickerCount: stickers.length,
    commentImageCapped: capped,
  };
}

async function handleExport(note, options) {
  const opts = options || { includeComments: false };
  // 「收录评论」未勾选：在数据源头剥离评论（预览/HTML/EPUB 三出口一致生效，
  // 评论配图也一并跳过下载，省时间）。评论捕获不受影响，重新勾选导出即可带上。
  if (!opts.includeComments && note.comments) {
    note = Object.assign({}, note, { comments: { total: 0, list: [] } });
  }
  const dl = await downloadImages(note);
  const payload = {
    note,
    options: opts,
    generatedAt: new Date().toISOString(),
    imageFailed: dl.failed,
  };
  await chrome.storage.local.set({ exportPayload: payload });
  await chrome.tabs.create({ url: PREVIEW_URL });
  return {
    ok: true,
    imageCount: (note.images || []).length,
    commentImageCount: dl.commentImageCount,
    stickerCount: dl.stickerCount,
    commentImageCapped: dl.commentImageCapped,
    imageFailed: dl.failed,
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'XHS_EXPORT') return;
  handleExport(msg.note, msg.options)
    .then(sendResponse)
    .catch((e) => sendResponse({ ok: false, error: String(e && e.message) }));
  return true; // 异步 sendResponse
});
